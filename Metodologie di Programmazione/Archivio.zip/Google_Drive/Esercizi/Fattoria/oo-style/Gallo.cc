#include "Gallo.hh"

const char*
Gallo::nome() const {
  return "gallo";
}

Genere
Gallo::genere() const {
  return MASCHILE;
}

const char*
Gallo::verso() const {
  return "chicchiricchì";
}

