#include "Animale.hh"

Animale::~Animale() {
}
