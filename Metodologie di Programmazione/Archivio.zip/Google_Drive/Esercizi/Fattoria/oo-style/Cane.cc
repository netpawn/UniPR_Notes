#include "Cane.hh"

const char*
Cane::nome() const {
  return "cane";
}

Genere
Cane::genere() const {
  return MASCHILE;
}

const char*
Cane::verso() const {
  return "bau!";
}

