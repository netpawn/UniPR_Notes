#include "Barboncino.hh"

const char* Barboncino::verso() const {
  return "wof";
}
