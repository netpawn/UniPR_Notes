#include <iostream> 
#include "classecubo.hh"

int main(){
    cubo c;  //costr 
    cubo c1=c; //costr copia 
    cubo (cubo1); //costr diretta 
    c.lato = 1; 
}