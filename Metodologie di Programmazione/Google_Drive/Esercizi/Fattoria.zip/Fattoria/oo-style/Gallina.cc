#include "Gallina.hh"

const char*
Gallina::nome() const {
  return "gallina";
}

Genere
Gallina::genere() const {
  return FEMMINILE;
}

const char*
Gallina::verso() const {
  return "coccodè";
}

