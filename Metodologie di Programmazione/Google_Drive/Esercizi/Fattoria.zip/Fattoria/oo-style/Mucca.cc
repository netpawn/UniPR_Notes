#include "Mucca.hh"

const char*
Mucca::nome() const {
  return "mucca";
}

Genere
Mucca::genere() const {
  return FEMMINILE;
}

const char*
Mucca::verso() const {
  return "muuuu";
}

